# AI Trading Bot
Run `python app.py` to start the bot dashboard.
